package top01;

public class Ex090201 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i1 = 1;
		System.out.println("整數: i1:" + i1);
		boolean b1 = true;
		boolean b2 = false;
		System.out.print("布林: b1:" + b1);
		System.out.println(", b2:" + b2);

		String s1 = "123", s2 = "456";
		System.out.println("字串: s1+S2:" + s1 + s2);

		float f1 = 10;
		double d1 = 10;
		System.out.print("浮點數: f1:" + f1);
		System.out.println(", d1:" + d1);

		int math = 100, chn = 95, eng = 90;
		int sum = math + chn + eng;
		double avg = sum / 3;
		System.out.println("計算平均: avg:" + avg);

		char c = 'c';
		System.out.println("輸出字元: c:" + c);

	}

}